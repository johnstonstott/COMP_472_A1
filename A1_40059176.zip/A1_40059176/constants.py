# -------------------------------------------------------
# Assignment 1
# Written by Johnston Stott (40059176)
# For COMP 472 Section ABIX – Summer 2020
# --------------------------------------------------------

MIN_LON = -73.59  # Farthest west
MAX_LON = -73.55  # Farthest east
MIN_LAT = 45.49  # Farthest south
MAX_LAT = 45.53  # Farthest north
TOT_LON = 0.04
TOT_LAT = 0.04
